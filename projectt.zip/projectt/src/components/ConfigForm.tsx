import React, { useState } from 'react';
import { Globe, Network, Download, Settings } from 'lucide-react';

interface ConfigFormProps {
  onConfigGenerated: () => void;
}

const ConfigForm: React.FC<ConfigFormProps> = ({ onConfigGenerated }) => {
  const [serverAddr, setServerAddr] = useState('');
  const [serverPort, setServerPort] = useState(7000);
  const [portString, setPortString] = useState('22, 80, 7000-7999');
  const [protocol, setProtocol] = useState<'tcp' | 'udp' | 'both'>('tcp');
  const [localIP, setLocalIP] = useState('127.0.0.1');
  const [generatedConfig, setGeneratedConfig] = useState<any>(null);
  const [isLoading, setIsLoading] = useState(false);

  // Get the API base URL dynamically
  const getApiUrl = () => {
    if (typeof window !== 'undefined') {
      const protocol = window.location.protocol;
      const hostname = window.location.hostname;
      
      // In development, use localhost:3001
      if (hostname === 'localhost' || hostname === '127.0.0.1') {
        return 'http://localhost:3001';
      }
      
      // In production, use the same host but port 3001
      return `${protocol}//${hostname}:3001`;
    }
    return 'http://localhost:3001';
  };

  const generateConfigs = async () => {
    if (!serverAddr.trim()) {
      alert('Please enter a server address');
      return;
    }

    if (!portString.trim()) {
      alert('Please enter port(s)');
      return;
    }

    const config = {
      serverAddr,
      serverPort,
      portString,
      protocol,
      localIP
    };

    setIsLoading(true);

    try {
      const apiUrl = `${getApiUrl()}/api/generate-configs`;
      console.log('Making request to:', apiUrl);
      console.log('Request payload:', config);
      
      const response = await fetch(apiUrl, {
        method: 'POST',
        headers: { 
          'Content-Type': 'application/json',
          'Accept': 'application/json'
        },
        body: JSON.stringify(config)
      });

      console.log('Response status:', response.status);
      
      if (!response.ok) {
        const errorText = await response.text();
        console.error('Response error:', errorText);
        throw new Error(`HTTP error! status: ${response.status} - ${errorText}`);
      }

      const data = await response.json();
      console.log('Response data:', data);
      
      if (data.success) {
        setGeneratedConfig(data.config);
        onConfigGenerated();
        
        const totalProxies = data.config?.totalProxies || 
                           (data.config?.ports?.length || 0) * (protocol === 'both' ? 2 : 1);
        
        alert(`Successfully generated configuration file with ${totalProxies} proxies!`);
      } else {
        alert('Error: ' + (data.message || 'Unknown error occurred'));
      }
    } catch (error) {
      console.error('Fetch error:', error);
      alert('Error generating configuration: ' + error.message + '\n\nPlease check if the server is running on port 3001');
    } finally {
      setIsLoading(false);
    }
  };

  const getPortPreview = () => {
    try {
      const ports = [];
      const parts = portString.split(',');
      
      parts.forEach(part => {
        part = part.trim();
        if (part.includes('-')) {
          const [start, end] = part.split('-').map(p => parseInt(p.trim()));
          if (!isNaN(start) && !isNaN(end) && start <= end) {
            if (end - start > 10) {
              ports.push(`${start}-${end} (${end - start + 1} ports)`);
            } else {
              for (let i = start; i <= end; i++) {
                ports.push(i.toString());
              }
            }
          }
        } else {
          const port = parseInt(part);
          if (!isNaN(port)) {
            ports.push(port.toString());
          }
        }
      });
      
      return ports.slice(0, 10).join(', ') + (ports.length > 10 ? '...' : '');
    } catch {
      return 'Invalid format';
    }
  };

  return (
    <div className="space-y-6">
      <div className="bg-gradient-to-r from-blue-50 to-indigo-50 p-6 rounded-lg border border-blue-200">
        <h2 className="text-2xl font-bold text-gray-900 mb-4 flex items-center">
          <Globe className="w-6 h-6 mr-2 text-blue-600" />
          Server Configuration
        </h2>
        
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">
              Server Address (IP)
            </label>
            <input
              type="text"
              value={serverAddr}
              onChange={(e) => setServerAddr(e.target.value)}
              placeholder="e.g., 192.168.1.100"
              className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
            />
          </div>
          
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">
              Server Port
            </label>
            <input
              type="number"
              value={serverPort}
              onChange={(e) => setServerPort(parseInt(e.target.value))}
              placeholder="7000"
              className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
            />
          </div>
        </div>
      </div>

      <div className="bg-white p-6 border border-gray-200 rounded-lg shadow-sm">
        <h3 className="text-xl font-bold text-gray-900 mb-4 flex items-center">
          <Network className="w-5 h-5 mr-2 text-blue-600" />
          Proxy Configuration
        </h3>
        
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
          <div className="lg:col-span-2">
            <label className="block text-sm font-medium text-gray-700 mb-2">
              Ports (e.g., 22, 80, 443, 7000-7999)
            </label>
            <input
              type="text"
              value={portString}
              onChange={(e) => setPortString(e.target.value)}
              placeholder="22, 80, 7000-7999"
              className="w-full px-3 py-2 border border-gray-300 rounded-md focus:ring-2 focus:ring-blue-500 focus:border-transparent"
            />
            <p className="text-xs text-gray-500 mt-1">
              Preview: {getPortPreview()}
            </p>
          </div>
          
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">
              Protocol
            </label>
            <select
              value={protocol}
              onChange={(e) => setProtocol(e.target.value as 'tcp' | 'udp' | 'both')}
              className="w-full px-3 py-2 border border-gray-300 rounded-md focus:ring-2 focus:ring-blue-500 focus:border-transparent"
            >
              <option value="tcp">TCP</option>
              <option value="udp">UDP</option>
              <option value="both">Both (TCP + UDP)</option>
            </select>
          </div>
          
          <div className="lg:col-span-3">
            <label className="block text-sm font-medium text-gray-700 mb-2">
              Local IP Address
            </label>
            <input
              type="text"
              value={localIP}
              onChange={(e) => setLocalIP(e.target.value)}
              placeholder="127.0.0.1"
              className="w-full px-3 py-2 border border-gray-300 rounded-md focus:ring-2 focus:ring-blue-500 focus:border-transparent"
            />
          </div>
        </div>
      </div>

      <div className="flex justify-center">
        <button
          onClick={generateConfigs}
          disabled={isLoading}
          className="flex items-center space-x-2 px-8 py-3 bg-green-600 text-white rounded-lg hover:bg-green-700 disabled:opacity-50 disabled:cursor-not-allowed transition-colors text-lg font-medium"
        >
          <Download className="w-5 h-5" />
          <span>{isLoading ? 'Generating...' : 'Generate Configuration'}</span>
        </button>
      </div>

      {/* Debug info */}
      <div className="bg-gray-100 p-4 rounded-lg text-sm">
        <p><strong>API URL:</strong> {getApiUrl()}/api/generate-configs</p>
        <p><strong>Current Host:</strong> {typeof window !== 'undefined' ? window.location.host : 'N/A'}</p>
      </div>

      {generatedConfig && (
        <div className="space-y-4">
          <h4 className="text-lg font-semibold text-gray-900 flex items-center">
            <Settings className="w-5 h-5 mr-2 text-green-600" />
            Generated Configuration File
          </h4>
          
          <div className="bg-gray-50 p-4 rounded-lg border">
            <div className="flex items-center justify-between mb-2">
              <h5 className="font-medium text-gray-900">{generatedConfig.fileName || 'frp-config.toml'}</h5>
              <div className="text-sm text-gray-600">
                <span className="mr-4">Ports: {generatedConfig.ports?.length || 0}</span>
                <span>Total Proxies: {generatedConfig.totalProxies || (generatedConfig.ports?.length || 0) * (protocol === 'both' ? 2 : 1)}</span>
              </div>
            </div>
            <details className="mt-2">
              <summary className="cursor-pointer text-blue-600 hover:text-blue-800 text-sm">
                View Configuration Content
              </summary>
              <pre className="mt-2 bg-gray-900 p-3 rounded text-green-400 text-xs overflow-x-auto whitespace-pre-wrap">
                {generatedConfig.content || 'No content available'}
              </pre>
            </details>
          </div>
        </div>
      )}
    </div>
  );
};

export default ConfigForm;