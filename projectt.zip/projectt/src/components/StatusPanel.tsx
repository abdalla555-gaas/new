import React from 'react';
import { Activity, Play, Square, Server, AlertTriangle, CheckCircle, RotateCcw, Settings } from 'lucide-react';

interface FRPStatus {
  status: string;
  processes: Array<{
    config: string;
    pid: number;
    killed: boolean;
  }>;
  totalConfigs: number;
  runningProcesses: number;
  autoRestart: boolean;
}

interface StatusPanelProps {
  status: FRPStatus;
  onStart: () => void;
  onStop: () => void;
  onToggleAutoRestart: () => void;
}

const StatusPanel: React.FC<StatusPanelProps> = ({ status, onStart, onStop, onToggleAutoRestart }) => {
  const getStatusIcon = () => {
    switch (status.status) {
      case 'running':
        return <CheckCircle className="w-8 h-8 text-green-600" />;
      case 'stopped':
        return <Activity className="w-8 h-8 text-gray-600" />;
      case 'error':
        return <AlertTriangle className="w-8 h-8 text-red-600" />;
      default:
        return <Activity className="w-8 h-8 text-gray-600" />;
    }
  };

  const getStatusMessage = () => {
    if (status.runningProcesses > 0) {
      return `${status.runningProcesses} FRP process${status.runningProcesses !== 1 ? 'es' : ''} running out of ${status.totalConfigs} total configurations.`;
    }
    return 'No FRP processes are currently running.';
  };

  const getStatusColor = () => {
    switch (status.status) {
      case 'running':
        return 'bg-green-50 border-green-200';
      case 'stopped':
        return 'bg-gray-50 border-gray-200';
      case 'error':
        return 'bg-red-50 border-red-200';
      default:
        return 'bg-gray-50 border-gray-200';
    }
  };

  return (
    <div className="space-y-6">
      <h2 className="text-2xl font-bold text-gray-900 flex items-center">
        <Server className="w-6 h-6 mr-2 text-blue-600" />
        FRP Service Status
      </h2>

      <div className={`p-6 rounded-lg border-2 ${getStatusColor()}`}>
        <div className="flex items-center space-x-4">
          {getStatusIcon()}
          <div className="flex-1">
            <h3 className="text-xl font-semibold text-gray-900 capitalize">
              Status: {status.status}
            </h3>
            <p className="text-gray-700 mt-1">{getStatusMessage()}</p>
            <div className="mt-3 flex items-center space-x-4 text-sm text-gray-600">
              <span>Total Configs: <strong>{status.totalConfigs}</strong></span>
              <span>Running: <strong className="text-green-600">{status.runningProcesses}</strong></span>
              <span>Auto-restart: <strong className={status.autoRestart ? 'text-green-600' : 'text-red-600'}>
                {status.autoRestart ? 'Enabled' : 'Disabled'}
              </strong></span>
            </div>
          </div>
        </div>
      </div>

      {status.processes && status.processes.length > 0 && (
        <div className="bg-white border border-gray-200 rounded-lg p-6">
          <h3 className="text-lg font-semibold text-gray-900 mb-4">Running Processes</h3>
          <div className="space-y-2">
            {status.processes.map((process, index) => (
              <div key={index} className="flex items-center justify-between p-3 bg-gray-50 rounded-lg">
                <div className="flex items-center space-x-3">
                  <div className={`w-3 h-3 rounded-full ${process.killed ? 'bg-red-500' : 'bg-green-500'}`}></div>
                  <span className="font-medium">{process.config}</span>
                </div>
                <div className="text-sm text-gray-600">
                  PID: <code className="bg-gray-200 px-2 py-1 rounded">{process.pid}</code>
                  <span className={`ml-2 px-2 py-1 rounded text-xs ${
                    process.killed ? 'bg-red-100 text-red-800' : 'bg-green-100 text-green-800'
                  }`}>
                    {process.killed ? 'Stopped' : 'Running'}
                  </span>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      <div className="bg-white border border-gray-200 rounded-lg p-6">
        <h3 className="text-lg font-semibold text-gray-900 mb-4">Service Controls</h3>
        
        <div className="flex flex-wrap gap-4">
          <button
            onClick={onStart}
            className="flex items-center space-x-2 px-6 py-3 bg-green-600 text-white rounded-lg hover:bg-green-700 transition-colors"
          >
            <Play className="w-5 h-5" />
            <span>Start All</span>
          </button>
          
          <button
            onClick={onStop}
            disabled={status.runningProcesses === 0}
            className="flex items-center space-x-2 px-6 py-3 bg-red-600 text-white rounded-lg hover:bg-red-700 disabled:opacity-50 disabled:cursor-not-allowed transition-colors"
          >
            <Square className="w-5 h-5" />
            <span>Stop All</span>
          </button>

          <button
            onClick={onToggleAutoRestart}
            className={`flex items-center space-x-2 px-6 py-3 rounded-lg transition-colors ${
              status.autoRestart 
                ? 'bg-orange-600 text-white hover:bg-orange-700' 
                : 'bg-blue-600 text-white hover:bg-blue-700'
            }`}
          >
            <RotateCcw className="w-5 h-5" />
            <span>{status.autoRestart ? 'Disable' : 'Enable'} Auto-restart</span>
          </button>
        </div>
      </div>

      <div className="bg-blue-50 border border-blue-200 rounded-lg p-6">
        <h3 className="text-lg font-semibold text-blue-900 mb-3 flex items-center">
          <Settings className="w-5 h-5 mr-2" />
          System Information
        </h3>
        
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4 text-sm">
          <div>
            <span className="font-medium text-blue-800">Overall Status:</span>
            <span className="ml-2 text-blue-700 capitalize">{status.status}</span>
          </div>
          
          <div>
            <span className="font-medium text-blue-800">Active Processes:</span>
            <span className="ml-2 text-blue-700">
              {status.runningProcesses} / {status.totalConfigs}
            </span>
          </div>
          
          <div>
            <span className="font-medium text-blue-800">Auto-restart:</span>
            <span className="ml-2 text-blue-700">
              {status.autoRestart ? 'Enabled' : 'Disabled'}
            </span>
          </div>
          
          <div>
            <span className="font-medium text-blue-800">Config Directory:</span>
            <span className="ml-2 text-blue-700 font-mono text-xs">
              ./configs/
            </span>
          </div>
        </div>
      </div>

      <div className="bg-yellow-50 border border-yellow-200 rounded-lg p-4">
        <h4 className="font-semibold text-yellow-800 mb-2">Important Notes:</h4>
        <ul className="text-sm text-yellow-700 space-y-1">
          <li>• Each configuration file runs as a separate FRP process</li>
          <li>• Auto-restart will automatically restart crashed processes</li>
          <li>• Make sure the FRP server is running on the target machine</li>
          <li>• Verify that firewall rules allow the configured ports</li>
          <li>• Check network connectivity between client and server</li>
        </ul>
      </div>
    </div>
  );
};

export default StatusPanel;