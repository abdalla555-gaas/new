import React, { useState } from 'react';
import { Play, Trash2, Download, FileText, Calendar, HardDrive, Edit3, Save, X, Square } from 'lucide-react';

interface Config {
  name: string;
  path: string;
  size: number;
  modified: string;
  content: string;
}

interface ConfigListProps {
  configs: Config[];
  onConfigsChange: () => void;
  onStartFRP: (configFile: string) => void;
  onStopFRP: (configFile: string) => void;
  frpStatus: any;
}

const ConfigList: React.FC<ConfigListProps> = ({ 
  configs, 
  onConfigsChange, 
  onStartFRP,
  onStopFRP,
  frpStatus 
}) => {
  const [editingConfig, setEditingConfig] = useState<string | null>(null);
  const [editContent, setEditContent] = useState('');

  // Get the API base URL dynamically
  const getApiUrl = () => {
    if (typeof window !== 'undefined') {
      const protocol = window.location.protocol;
      const hostname = window.location.hostname;
      
      // In development, use localhost:3001
      if (hostname === 'localhost' || hostname === '127.0.0.1') {
        return 'http://localhost:3001';
      }
      
      // In production, use the same host but port 3001
      return `${protocol}//${hostname}:3001`;
    }
    return 'http://localhost:3001';
  };

  const formatFileSize = (bytes: number) => {
    if (bytes === 0) return '0 Bytes';
    const k = 1024;
    const sizes = ['Bytes', 'KB', 'MB', 'GB'];
    const i = Math.floor(Math.log(bytes) / Math.log(k));
    return parseFloat((bytes / Math.pow(k, i)).toFixed(2)) + ' ' + sizes[i];
  };

  const formatDate = (dateString: string) => {
    return new Date(dateString).toLocaleString();
  };

  const isConfigRunning = (configName: string) => {
    return frpStatus.processes?.some((p: any) => p.config === configName && !p.killed);
  };

  const getConfigProcess = (configName: string) => {
    return frpStatus.processes?.find((p: any) => p.config === configName);
  };

  const deleteConfig = async (filename: string) => {
    if (!confirm(`Are you sure you want to delete ${filename}?`)) {
      return;
    }

    try {
      const response = await fetch(`${getApiUrl()}/api/configs/${filename}`, {
        method: 'DELETE'
      });
      
      const data = await response.json();
      
      if (data.success) {
        onConfigsChange();
        alert('Configuration deleted successfully');
      } else {
        alert('Error: ' + data.message);
      }
    } catch (error) {
      alert('Error deleting configuration: ' + error);
    }
  };

  const downloadConfig = (config: Config) => {
    const blob = new Blob([config.content], { type: 'text/plain' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = config.name;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
  };

  const startEditing = (config: Config) => {
    setEditingConfig(config.name);
    setEditContent(config.content);
  };

  const cancelEditing = () => {
    setEditingConfig(null);
    setEditContent('');
  };

  const saveConfig = async (filename: string) => {
    try {
      const response = await fetch(`${getApiUrl()}/api/configs/${filename}`, {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ content: editContent })
      });
      
      const data = await response.json();
      
      if (data.success) {
        setEditingConfig(null);
        setEditContent('');
        onConfigsChange();
        alert('Configuration updated successfully');
      } else {
        alert('Error: ' + data.message);
      }
    } catch (error) {
      alert('Error updating configuration: ' + error);
    }
  };

  if (configs.length === 0) {
    return (
      <div className="text-center py-12">
        <FileText className="w-16 h-16 text-gray-400 mx-auto mb-4" />
        <h3 className="text-xl font-medium text-gray-900 mb-2">No configurations found</h3>
        <p className="text-gray-600">Create your first FRP configuration to get started.</p>
      </div>
    );
  }

  return (
    <div className="space-y-4">
      <div className="flex items-center justify-between">
        <h2 className="text-2xl font-bold text-gray-900">Configuration Files</h2>
        <div className="text-sm text-gray-600">
          {configs.length} configuration{configs.length !== 1 ? 's' : ''} found
          {frpStatus.runningProcesses > 0 && (
            <span className="ml-2 text-green-600 font-medium">
              ({frpStatus.runningProcesses} running)
            </span>
          )}
        </div>
      </div>

      <div className="grid gap-4">
        {configs.map((config) => {
          const isRunning = isConfigRunning(config.name);
          const process = getConfigProcess(config.name);
          
          return (
            <div key={config.name} className="bg-white border border-gray-200 rounded-lg p-6 shadow-sm hover:shadow-md transition-shadow">
              <div className="flex items-start justify-between">
                <div className="flex-1">
                  <div className="flex items-center space-x-3 mb-3">
                    <FileText className="w-6 h-6 text-blue-600" />
                    <h3 className="text-lg font-semibold text-gray-900">{config.name}</h3>
                    {isRunning && (
                      <span className="px-2 py-1 bg-green-100 text-green-800 text-xs font-medium rounded-full">
                        Running (PID: {process?.pid})
                      </span>
                    )}
                  </div>
                  
                  <div className="grid grid-cols-1 md:grid-cols-3 gap-4 text-sm text-gray-600 mb-4">
                    <div className="flex items-center space-x-2">
                      <HardDrive className="w-4 h-4" />
                      <span>{formatFileSize(config.size)}</span>
                    </div>
                    <div className="flex items-center space-x-2">
                      <Calendar className="w-4 h-4" />
                      <span>{formatDate(config.modified)}</span>
                    </div>
                    <div className="flex items-center space-x-2">
                      <span className="text-gray-500">Path:</span>
                      <code className="bg-gray-100 px-2 py-1 rounded text-xs">{config.path}</code>
                    </div>
                  </div>

                  {editingConfig === config.name ? (
                    <div className="mb-4">
                      <div className="flex items-center justify-between mb-2">
                        <h4 className="font-medium text-gray-900">Edit Configuration</h4>
                        <div className="flex space-x-2">
                          <button
                            onClick={() => saveConfig(config.name)}
                            className="flex items-center space-x-1 px-3 py-1 bg-green-600 text-white rounded text-sm hover:bg-green-700"
                          >
                            <Save className="w-3 h-3" />
                            <span>Save</span>
                          </button>
                          <button
                            onClick={cancelEditing}
                            className="flex items-center space-x-1 px-3 py-1 bg-gray-600 text-white rounded text-sm hover:bg-gray-700"
                          >
                            <X className="w-3 h-3" />
                            <span>Cancel</span>
                          </button>
                        </div>
                      </div>
                      <textarea
                        value={editContent}
                        onChange={(e) => setEditContent(e.target.value)}
                        className="w-full h-40 p-3 border border-gray-300 rounded-lg font-mono text-sm focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                      />
                    </div>
                  ) : (
                    <details className="mb-4">
                      <summary className="cursor-pointer text-blue-600 hover:text-blue-800 font-medium">
                        View Configuration Content
                      </summary>
                      <div className="mt-2 bg-gray-900 p-4 rounded-lg">
                        <pre className="text-green-400 text-sm overflow-x-auto whitespace-pre-wrap">
                          {config.content}
                        </pre>
                      </div>
                    </details>
                  )}
                </div>
              </div>

              <div className="flex items-center justify-end space-x-3 pt-4 border-t border-gray-200">
                <button
                  onClick={() => downloadConfig(config)}
                  className="flex items-center space-x-2 px-4 py-2 text-blue-600 hover:text-blue-800 hover:bg-blue-50 rounded-lg transition-colors"
                >
                  <Download className="w-4 h-4" />
                  <span>Download</span>
                </button>
                
                <button
                  onClick={() => startEditing(config)}
                  disabled={editingConfig !== null}
                  className="flex items-center space-x-2 px-4 py-2 text-purple-600 hover:text-purple-800 hover:bg-purple-50 rounded-lg transition-colors disabled:opacity-50 disabled:cursor-not-allowed"
                >
                  <Edit3 className="w-4 h-4" />
                  <span>Edit</span>
                </button>
                
                {isRunning ? (
                  <button
                    onClick={() => onStopFRP(config.name)}
                    className="flex items-center space-x-2 px-4 py-2 bg-red-600 text-white rounded-lg hover:bg-red-700 transition-colors"
                  >
                    <Square className="w-4 h-4" />
                    <span>Stop</span>
                  </button>
                ) : (
                  <button
                    onClick={() => onStartFRP(config.name)}
                    className="flex items-center space-x-2 px-4 py-2 bg-green-600 text-white rounded-lg hover:bg-green-700 transition-colors"
                  >
                    <Play className="w-4 h-4" />
                    <span>Start</span>
                  </button>
                )}
                
                <button
                  onClick={() => deleteConfig(config.name)}
                  className="flex items-center space-x-2 px-4 py-2 text-red-600 hover:text-red-800 hover:bg-red-50 rounded-lg transition-colors"
                >
                  <Trash2 className="w-4 h-4" />
                  <span>Delete</span>
                </button>
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
};

export default ConfigList;