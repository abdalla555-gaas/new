import React, { useState, useEffect } from 'react';
import { 
  Server, 
  Play, 
  Square, 
  Plus, 
  Settings,
  Network,
  Activity
} from 'lucide-react';
import ConfigForm from './components/ConfigForm';
import ConfigList from './components/ConfigList';
import StatusPanel from './components/StatusPanel';

interface FRPStatus {
  status: string;
  processes: Array<{
    config: string;
    pid: number;
    killed: boolean;
  }>;
  totalConfigs: number;
  runningProcesses: number;
  autoRestart: boolean;
}

function App() {
  const [activeTab, setActiveTab] = useState('create');
  const [frpStatus, setFrpStatus] = useState<FRPStatus>({ 
    status: 'stopped', 
    processes: [],
    totalConfigs: 0,
    runningProcesses: 0,
    autoRestart: true
  });
  const [configs, setConfigs] = useState([]);

  // Get the API base URL dynamically
  const getApiUrl = () => {
    if (typeof window !== 'undefined') {
      const protocol = window.location.protocol;
      const hostname = window.location.hostname;
      const port = window.location.port;
      
      // In development, use localhost:3001
      if (hostname === 'localhost' || hostname === '127.0.0.1') {
        return 'http://localhost:3001';
      }
      
      // In production, use the same host but port 3001
      return `${protocol}//${hostname}:3001`;
    }
    return 'http://localhost:3001';
  };

  useEffect(() => {
    fetchStatus();
    fetchConfigs();
    
    // Poll status every 3 seconds
    const interval = setInterval(fetchStatus, 3000);
    return () => clearInterval(interval);
  }, []);

  const fetchStatus = async () => {
    try {
      const response = await fetch(`${getApiUrl()}/api/status`);
      if (!response.ok) {
        throw new Error(`HTTP error! status: ${response.status}`);
      }
      const data = await response.json();
      setFrpStatus(data);
    } catch (error) {
      console.error('Error fetching status:', error);
      // Set offline status if can't reach server
      setFrpStatus(prev => ({ ...prev, status: 'offline' }));
    }
  };

  const fetchConfigs = async () => {
    try {
      const response = await fetch(`${getApiUrl()}/api/configs`);
      if (!response.ok) {
        throw new Error(`HTTP error! status: ${response.status}`);
      }
      const data = await response.json();
      setConfigs(data);
    } catch (error) {
      console.error('Error fetching configs:', error);
    }
  };

  const handleStartFRP = async (configFile?: string) => {
    try {
      const response = await fetch(`${getApiUrl()}/api/start-frp`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ configFile })
      });
      
      if (!response.ok) {
        throw new Error(`HTTP error! status: ${response.status}`);
      }
      
      const data = await response.json();
      
      if (data.success) {
        fetchStatus();
      }
      
      alert(data.message);
    } catch (error) {
      alert('Error starting FRP: ' + error.message);
    }
  };

  const handleStopFRP = async (configFile?: string) => {
    try {
      const response = await fetch(`${getApiUrl()}/api/stop-frp`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ configFile })
      });
      
      if (!response.ok) {
        throw new Error(`HTTP error! status: ${response.status}`);
      }
      
      const data = await response.json();
      
      if (data.success) {
        fetchStatus();
      }
      
      alert(data.message);
    } catch (error) {
      alert('Error stopping FRP: ' + error.message);
    }
  };

  const handleToggleAutoRestart = async () => {
    try {
      const response = await fetch(`${getApiUrl()}/api/toggle-auto-restart`, {
        method: 'POST'
      });
      
      if (!response.ok) {
        throw new Error(`HTTP error! status: ${response.status}`);
      }
      
      const data = await response.json();
      
      if (data.success) {
        fetchStatus();
        alert(data.message);
      }
    } catch (error) {
      alert('Error toggling auto-restart: ' + error.message);
    }
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'running': return 'text-green-600 bg-green-100';
      case 'stopped': return 'text-gray-600 bg-gray-100';
      case 'error': return 'text-red-600 bg-red-100';
      case 'offline': return 'text-orange-600 bg-orange-100';
      default: return 'text-gray-600 bg-gray-100';
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 to-indigo-100">
      <div className="container mx-auto px-4 py-8">
        {/* Header */}
        <div className="bg-white rounded-xl shadow-lg p-6 mb-8">
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-3">
              <div className="p-3 bg-blue-600 rounded-lg">
                <Server className="w-8 h-8 text-white" />
              </div>
              <div>
                <h1 className="text-3xl font-bold text-gray-900">FRP Config Manager</h1>
                <p className="text-gray-600">Fast Reverse Proxy Configuration Tool</p>
              </div>
            </div>
            
            <div className="flex items-center space-x-4">
              <div className={`px-4 py-2 rounded-full font-medium ${getStatusColor(frpStatus.status)}`}>
                <Activity className="w-4 h-4 inline mr-2" />
                {frpStatus.status.toUpperCase()}
                {frpStatus.runningProcesses > 0 && ` (${frpStatus.runningProcesses}/${frpStatus.totalConfigs})`}
              </div>
              
              <div className="flex space-x-2">
                <button
                  onClick={() => handleStartFRP()}
                  className="flex items-center space-x-2 px-4 py-2 bg-green-600 text-white rounded-lg hover:bg-green-700 transition-colors"
                >
                  <Play className="w-4 h-4" />
                  <span>Start All</span>
                </button>
                
                <button
                  onClick={() => handleStopFRP()}
                  disabled={frpStatus.runningProcesses === 0}
                  className="flex items-center space-x-2 px-4 py-2 bg-red-600 text-white rounded-lg hover:bg-red-700 disabled:opacity-50 disabled:cursor-not-allowed transition-colors"
                >
                  <Square className="w-4 h-4" />
                  <span>Stop All</span>
                </button>
              </div>
            </div>
          </div>
        </div>

        {/* Connection Status */}
        {frpStatus.status === 'offline' && (
          <div className="bg-orange-100 border border-orange-400 text-orange-700 px-4 py-3 rounded mb-6">
            <strong>Warning:</strong> Cannot connect to the backend server. Please ensure the server is running on port 3001.
            <br />
            <small>API URL: {getApiUrl()}</small>
          </div>
        )}

        {/* Navigation Tabs */}
        <div className="bg-white rounded-xl shadow-lg mb-8">
          <div className="flex border-b border-gray-200">
            <button
              onClick={() => setActiveTab('create')}
              className={`flex items-center space-x-2 px-6 py-4 font-medium transition-colors ${
                activeTab === 'create'
                  ? 'text-blue-600 border-b-2 border-blue-600'
                  : 'text-gray-600 hover:text-blue-600'
              }`}
            >
              <Plus className="w-5 h-5" />
              <span>Create Configs</span>
            </button>
            
            <button
              onClick={() => setActiveTab('manage')}
              className={`flex items-center space-x-2 px-6 py-4 font-medium transition-colors ${
                activeTab === 'manage'
                  ? 'text-blue-600 border-b-2 border-blue-600'
                  : 'text-gray-600 hover:text-blue-600'
              }`}
            >
              <Settings className="w-5 h-5" />
              <span>Manage Configs</span>
            </button>
            
            <button
              onClick={() => setActiveTab('status')}
              className={`flex items-center space-x-2 px-6 py-4 font-medium transition-colors ${
                activeTab === 'status'
                  ? 'text-blue-600 border-b-2 border-blue-600'
                  : 'text-gray-600 hover:text-blue-600'
              }`}
            >
              <Network className="w-5 h-5" />
              <span>Status & Control</span>
            </button>
          </div>
          
          <div className="p-6">
            {activeTab === 'create' && (
              <ConfigForm onConfigGenerated={fetchConfigs} />
            )}
            
            {activeTab === 'manage' && (
              <ConfigList 
                configs={configs} 
                onConfigsChange={fetchConfigs}
                onStartFRP={handleStartFRP}
                onStopFRP={handleStopFRP}
                frpStatus={frpStatus}
              />
            )}
            
            {activeTab === 'status' && (
              <StatusPanel 
                status={frpStatus}
                onStart={() => handleStartFRP()}
                onStop={() => handleStopFRP()}
                onToggleAutoRestart={handleToggleAutoRestart}
              />
            )}
          </div>
        </div>
      </div>
    </div>
  );
}

export default App;