import express from 'express';
import cors from 'cors';
import fs from 'fs-extra';
import path from 'path';
import { spawn } from 'child_process';
import { fileURLToPath } from 'url';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const app = express();
const PORT = process.env.PORT || 3001;

// Middleware
app.use(cors());
app.use(express.json());

// Serve static files in production
if (process.env.NODE_ENV === 'production') {
  app.use(express.static(path.join(__dirname, '../dist')));
}

// Store FRP processes
let frpProcesses = new Map();
let autoRestart = true;

// Config directory
const configDir = path.join(__dirname, '../configs');
await fs.ensureDir(configDir);

// Parse port ranges like "22, 80, 7000-7999"
function parsePortRange(portString) {
  const ports = [];
  const parts = portString.split(',');
  
  parts.forEach(part => {
    part = part.trim();
    if (part.includes('-')) {
      const [start, end] = part.split('-').map(p => parseInt(p.trim()));
      if (!isNaN(start) && !isNaN(end) && start <= end) {
        for (let i = start; i <= end; i++) {
          ports.push(i);
        }
      }
    } else {
      const port = parseInt(part);
      if (!isNaN(port)) {
        ports.push(port);
      }
    }
  });
  
  return ports;
}

// Generate single FRP config with multiple proxies
function generateFRPConfig(serverAddr, serverPort, ports, protocol, localIP) {
  let configContent = `serverAddr = "${serverAddr}"\n`;
  configContent += `serverPort = ${serverPort}\n\n`;
  
  ports.forEach(port => {
    if (protocol === 'both') {
      // TCP proxy
      configContent += `[[proxies]]\n`;
      configContent += `name = "port${port}tcp"\n`;
      configContent += `type = "tcp"\n`;
      configContent += `localIP = "${localIP}"\n`;
      configContent += `localPort = ${port}\n`;
      configContent += `remotePort = ${port}\n\n`;
      
      // UDP proxy
      configContent += `[[proxies]]\n`;
      configContent += `name = "port${port}udp"\n`;
      configContent += `type = "udp"\n`;
      configContent += `localIP = "${localIP}"\n`;
      configContent += `localPort = ${port}\n`;
      configContent += `remotePort = ${port}\n\n`;
    } else {
      // Single protocol proxy
      configContent += `[[proxies]]\n`;
      configContent += `name = "port${port}${protocol}"\n`;
      configContent += `type = "${protocol}"\n`;
      configContent += `localIP = "${localIP}"\n`;
      configContent += `localPort = ${port}\n`;
      configContent += `remotePort = ${port}\n\n`;
    }
  });
  
  return configContent;
}

// Generate unique config filename
async function generateUniqueConfigName() {
  const files = await fs.readdir(configDir);
  const configFiles = files.filter(file => file.match(/^config\d+\.toml$/));
  
  if (configFiles.length === 0) {
    return 'config1.toml';
  }
  
  // Extract numbers from existing config files
  const numbers = configFiles.map(file => {
    const match = file.match(/^config(\d+)\.toml$/);
    return match ? parseInt(match[1]) : 0;
  });
  
  // Find the next available number
  const maxNumber = Math.max(...numbers);
  return `config${maxNumber + 1}.toml`;
}

// Auto-restart function
function setupAutoRestart(configFile, childProcess) {
  childProcess.on('exit', (code, signal) => {
    console.log(`FRP process for ${configFile} exited with code ${code}, signal ${signal}`);
    
    if (autoRestart && frpProcesses.has(configFile)) {
      console.log(`Auto-restarting FRP for ${configFile}...`);
      setTimeout(() => {
        startSingleFRP(configFile);
      }, 2000);
    }
  });
  
  childProcess.on('error', (error) => {
    console.error(`FRP process error for ${configFile}:`, error);
    if (autoRestart && frpProcesses.has(configFile)) {
      console.log(`Auto-restarting FRP for ${configFile} after error...`);
      setTimeout(() => {
        startSingleFRP(configFile);
      }, 5000);
    }
  });
}

// Start single FRP process
function startSingleFRP(configFile) {
  const configPath = path.join(configDir, configFile);
  
  if (!fs.existsSync(configPath)) {
    console.error(`Config file not found: ${configPath}`);
    return false;
  }
  
  try {
    // Check if frpc binary exists
    const frpcPath = './frpc';
    if (!fs.existsSync(frpcPath)) {
      console.error('frpc binary not found. Please ensure frpc is in the project root directory.');
      return false;
    }
    
    console.log(`Starting FRP for ${configFile} with config: ${configPath}`);
    
    // Spawn the FRP client process
    const childProcess = spawn(frpcPath, ['-c', configPath], {
      stdio: ['pipe', 'pipe', 'pipe'],
      cwd: process.cwd(),
      detached: false
    });
    
    // Store the process
    frpProcesses.set(configFile, childProcess);
    
    // Setup auto-restart monitoring
    setupAutoRestart(configFile, childProcess);
    
    // Handle stdout
    childProcess.stdout.on('data', (data) => {
      console.log(`FRP ${configFile} stdout: ${data.toString().trim()}`);
    });
    
    // Handle stderr
    childProcess.stderr.on('data', (data) => {
      console.error(`FRP ${configFile} stderr: ${data.toString().trim()}`);
    });
    
    console.log(`Started FRP for ${configFile} with PID: ${childProcess.pid}`);
    return true;
  } catch (error) {
    console.error(`Error starting FRP for ${configFile}:`, error);
    return false;
  }
}

// API ENDPOINTS

// Health check
app.get('/api/health', (req, res) => {
  res.json({ 
    status: 'ok', 
    timestamp: new Date().toISOString(),
    port: PORT 
  });
});

// Get status
app.get('/api/status', (req, res) => {
  const processes = Array.from(frpProcesses.entries()).map(([config, childProcess]) => ({
    config,
    pid: childProcess.pid,
    killed: childProcess.killed
  }));
  
  const runningCount = processes.filter(p => !p.killed).length;
  const status = runningCount > 0 ? 'running' : 'stopped';
  
  res.json({ 
    status,
    processes,
    totalConfigs: frpProcesses.size,
    runningProcesses: runningCount,
    autoRestart
  });
});

// Generate unique config with multiple proxies
app.post('/api/generate-configs', async (req, res) => {
  try {
    console.log('Received generate-configs request:', req.body);
    
    const { serverAddr, serverPort = 7000, portString, protocol, localIP } = req.body;
    
    if (!serverAddr || !portString || !protocol || !localIP) {
      return res.status(400).json({
        success: false,
        message: 'Missing required fields: serverAddr, portString, protocol, localIP'
      });
    }
    
    const ports = parsePortRange(portString);
    console.log('Parsed ports:', ports);
    
    if (ports.length === 0) {
      return res.status(400).json({
        success: false,
        message: 'No valid ports found in port string'
      });
    }
    
    // Generate unique config file name
    const configFileName = await generateUniqueConfigName();
    const configPath = path.join(configDir, configFileName);
    
    const configContent = generateFRPConfig(serverAddr, serverPort, ports, protocol, localIP);
    await fs.writeFile(configPath, configContent);
    
    const totalProxies = protocol === 'both' ? ports.length * 2 : ports.length;
    
    console.log(`Generated configuration file ${configFileName} with ${totalProxies} proxies`);
    
    res.json({ 
      success: true, 
      message: `Generated configuration file ${configFileName} with ${totalProxies} proxies`,
      config: {
        fileName: configFileName,
        ports: ports,
        content: configContent,
        totalProxies: totalProxies
      }
    });
  } catch (error) {
    console.error('Error in generate-configs:', error);
    res.status(500).json({ 
      success: false, 
      message: 'Error generating configuration',
      error: error.message 
    });
  }
});

// Get all configs
app.get('/api/configs', async (req, res) => {
  try {
    const files = await fs.readdir(configDir);
    const configs = files.filter(file => file.endsWith('.toml'));
    
    const configList = await Promise.all(
      configs.map(async (file) => {
        const filePath = path.join(configDir, file);
        const content = await fs.readFile(filePath, 'utf8');
        const stats = await fs.stat(filePath);
        
        return {
          name: file,
          path: filePath,
          size: stats.size,
          modified: stats.mtime,
          content: content
        };
      })
    );
    
    res.json(configList);
  } catch (error) {
    console.error('Error in get configs:', error);
    res.status(500).json({ 
      success: false, 
      message: 'Error reading configurations',
      error: error.message 
    });
  }
});

// Start FRP
app.post('/api/start-frp', (req, res) => {
  const { configFile } = req.body;
  
  if (configFile) {
    // Start specific config
    if (frpProcesses.has(configFile)) {
      return res.json({ 
        success: false, 
        message: `FRP is already running for ${configFile}` 
      });
    }
    
    const success = startSingleFRP(configFile);
    if (success) {
      res.json({ 
        success: true, 
        message: `FRP started successfully for ${configFile}`,
        pid: frpProcesses.get(configFile)?.pid
      });
    } else {
      res.status(500).json({ 
        success: false, 
        message: `Error starting FRP for ${configFile}. Please ensure frpc binary is available.`
      });
    }
  } else {
    // Start all configs
    try {
      const files = fs.readdirSync(configDir);
      const configs = files.filter(file => file.endsWith('.toml'));
      
      let startedCount = 0;
      configs.forEach(config => {
        if (!frpProcesses.has(config)) {
          if (startSingleFRP(config)) {
            startedCount++;
          }
        }
      });
      
      if (startedCount > 0) {
        res.json({ 
          success: true, 
          message: `Started ${startedCount} FRP processes`,
          startedConfigs: startedCount
        });
      } else {
        res.json({ 
          success: false, 
          message: 'No new FRP processes started (already running or no configs found)'
        });
      }
    } catch (error) {
      res.status(500).json({ 
        success: false, 
        message: 'Error starting FRP processes',
        error: error.message 
      });
    }
  }
});

// Stop FRP
app.post('/api/stop-frp', (req, res) => {
  const { configFile } = req.body;
  
  try {
    if (configFile) {
      // Stop specific config
      const childProcess = frpProcesses.get(configFile);
      if (childProcess) {
        childProcess.kill('SIGTERM');
        frpProcesses.delete(configFile);
        
        res.json({ 
          success: true, 
          message: `FRP stopped successfully for ${configFile}` 
        });
      } else {
        res.json({ 
          success: false, 
          message: `FRP is not running for ${configFile}` 
        });
      }
    } else {
      // Stop all processes
      let stoppedCount = 0;
      frpProcesses.forEach((childProcess, config) => {
        childProcess.kill('SIGTERM');
        stoppedCount++;
      });
      
      frpProcesses.clear();
      
      res.json({ 
        success: true, 
        message: `Stopped ${stoppedCount} FRP processes` 
      });
    }
  } catch (error) {
    res.status(500).json({ 
      success: false, 
      message: 'Error stopping FRP',
      error: error.message 
    });
  }
});

// Update config
app.put('/api/configs/:filename', async (req, res) => {
  try {
    const filename = req.params.filename;
    const { content } = req.body;
    const filePath = path.join(configDir, filename);
    
    await fs.writeFile(filePath, content);
    
    res.json({ 
      success: true, 
      message: 'Configuration updated successfully' 
    });
  } catch (error) {
    res.status(500).json({ 
      success: false, 
      message: 'Error updating configuration',
      error: error.message 
    });
  }
});

// Delete config
app.delete('/api/configs/:filename', async (req, res) => {
  try {
    const filename = req.params.filename;
    const filePath = path.join(configDir, filename);
    
    // Stop the process if running
    const childProcess = frpProcesses.get(filename);
    if (childProcess) {
      childProcess.kill('SIGTERM');
      frpProcesses.delete(filename);
    }
    
    await fs.remove(filePath);
    
    res.json({ 
      success: true, 
      message: 'Configuration deleted successfully' 
    });
  } catch (error) {
    res.status(500).json({ 
      success: false, 
      message: 'Error deleting configuration',
      error: error.message 
    });
  }
});

// Toggle auto-restart
app.post('/api/toggle-auto-restart', (req, res) => {
  autoRestart = !autoRestart;
  res.json({ 
    success: true, 
    autoRestart,
    message: `Auto-restart ${autoRestart ? 'enabled' : 'disabled'}` 
  });
});

// Serve React app in production
if (process.env.NODE_ENV === 'production') {
  app.get('*', (req, res) => {
    res.sendFile(path.join(__dirname, '../dist/index.html'));
  });
}

// Start server
app.listen(PORT, '0.0.0.0', () => {
  console.log(`FRP Config Manager server running on port ${PORT}`);
  console.log(`Config directory: ${configDir}`);
  console.log(`Auto-restart: ${autoRestart ? 'enabled' : 'disabled'}`);
  console.log(`Server accessible at: http://0.0.0.0:${PORT}`);
  
  // Check if frpc binary exists
  const frpcPath = './frpc';
  if (!fs.existsSync(frpcPath)) {
    console.warn('WARNING: frpc binary not found in project root. Please download and place frpc binary in the project root directory.');
    console.warn('You can download frpc from: https://github.com/fatedier/frp/releases');
  } else {
    console.log('frpc binary found - ready to start FRP processes');
  }
});
